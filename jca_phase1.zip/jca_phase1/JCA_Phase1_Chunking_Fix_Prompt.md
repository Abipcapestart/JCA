# Implementation prompt — stop losing comparators to extraction truncation (chunked extraction)

Paste this to whoever implements it. Goal stated plainly, matching what was asked: **extract every comparator a source document actually contains — nothing dropped because a single LLM response ran out of room.** Raising `max_tokens` alone will not reliably deliver that goal; it buys time on today's documents and will quietly fail again on tomorrow's richer ones. The fix below is a stopgap you should do today, plus the structural fix that actually closes this off.

---

## Why "just raise it" isn't the fix — one paragraph, then move on

You already have direct proof this doesn't fully work: `a06.query_vocabulary`'s cap was raised once already, and it's still truncating 100% of the time on both calls in the latest run — the task (translate a full vocabulary into ~23 languages in one response) simply produces more output than any modest cap holds. `a08.extraction` is the same shape of problem: a comprehensive guideline document (like the SIOPE LGG guideline GT itself cites) can legitimately contain dozens of extractable claims, and that number grows as your source documents get richer over time. Whatever cap you pick today becomes tomorrow's truncation point. A cap-only fix also has a hard ceiling you should confirm before planning around it — check what your actual Bedrock model configuration in `providers/llm.py` allows as a maximum output token count; you may be closer to that number than you think. **Raise the cap now as an immediate stopgap** (it will recover some cases immediately, cheaply), **and do the chunking fix below as the real one.**

---

## Fix A (stopgap, do today, 10-minute change) — raise the extraction cap

**File: `config.py`**, line ~341: `extraction_max_tokens: int = 16000` → raise to at least 32000 (check your model's real ceiling first, per above, and go as high as that ceiling allows with headroom).

**File: `agents/a06_a08_retrieval.py`**, line 75: `max_tokens=1500` for `a06.query_vocabulary` — note this is what's in the codebase I reviewed; your production run's actual calls hit exactly 4000, meaning the deployed config already differs from this file. Reconcile that discrepancy first (find wherever the deployed cap of 4000 actually lives — it may be overridden elsewhere, e.g. an env var or a different config path), then raise it further — but see Fix C below, because for this specific prompt a cap raise alone is very unlikely to ever fully solve it (23 languages in one JSON response is just a lot of output).

This buys you an immediate, measurable improvement with almost no risk. Don't stop here.

---

## Fix B (the real fix) — chunk large documents before extraction instead of one call per document

**Where:** `agents/a06_a08_retrieval.py`, `_extract_one()` (~line 536) and `extract_from_documents()` (~line 512).

**Current shape (the problem):** one document → one `a08.extraction` call → one JSON response that must contain every extractable finding, however many there are:
```python
def _extract_one(doc: RetrievedDocument, population: Population,
                 intervention: Intervention, llm: LLMClient) -> List[EvidenceRecord]:
    payload = (
        f"REQUESTED INTERVENTION: {intervention.product_name}\n"
        f"REQUESTED POPULATION: {population.value('indication_disease')}\n"
        f"SOURCE CLASS: {doc.source_class}\n"
        f"SOURCE URL: {doc.resolved_url or doc.url}\n\n"
        f"DOCUMENT TEXT:\n{doc.text[:120000]}")
    parsed = llm.call_json("a08.extraction", payload,
                           max_tokens=C.LLM.extraction_max_tokens, default=[])
    if not isinstance(parsed, list):
        return []
    ...
```
Note it already truncates the *input* to 120,000 characters — so a genuinely long guideline PDF may already be losing content on the input side too, separate from the output-truncation problem. The chunking fix addresses both at once.

**New shape:** split the document text into overlapping windows, run extraction per window, merge:

```python
# New: a document-chunking helper. Put this near the top of
# agents/a06_a08_retrieval.py, alongside the other A8 helpers.

_CHUNK_CHARS = 30000       # conservative: budgeted to keep expected output
                           # comfortably under the (raised) extraction_max_tokens
_CHUNK_OVERLAP = 2000      # so a claim/table straddling a window boundary isn't split

def _chunk_document_text(text: str) -> List[str]:
    """Split long document text into overlapping windows, preferring to break
    on a paragraph/section boundary near the target size rather than mid-word
    or mid-table-row."""
    if len(text) <= _CHUNK_CHARS:
        return [text]
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + _CHUNK_CHARS, n)
        if end < n:
            # Prefer to break at a double-newline (paragraph/section break)
            # within the last 20% of the window, so we don't cut a
            # recommendation table row or a sentence in half.
            search_from = start + int(_CHUNK_CHARS * 0.8)
            break_at = text.rfind("\n\n", search_from, end)
            if break_at != -1:
                end = break_at
        chunks.append(text[start:end])
        if end >= n:
            break
        start = max(end - _CHUNK_OVERLAP, start + 1)  # overlap, always progress
    return chunks


def _extract_one(doc: RetrievedDocument, population: Population,
                 intervention: Intervention, llm: LLMClient) -> List[EvidenceRecord]:
    chunks = _chunk_document_text(doc.text)
    all_records: List[EvidenceRecord] = []
    for i, chunk_text in enumerate(chunks):
        payload = (
            f"REQUESTED INTERVENTION: {intervention.product_name}\n"
            f"REQUESTED POPULATION: {population.value('indication_disease')}\n"
            f"SOURCE CLASS: {doc.source_class}\n"
            f"SOURCE URL: {doc.resolved_url or doc.url}\n"
            + (f"NOTE: this is section {i + 1} of {len(chunks)} of a longer document; "
               f"extract only what THIS section states.\n" if len(chunks) > 1 else "")
            + f"\nDOCUMENT TEXT:\n{chunk_text}")
        parsed = llm.call_json("a08.extraction", payload,
                               max_tokens=C.LLM.extraction_max_tokens, default=[])
        if not isinstance(parsed, list):
            # Log this — see the visibility fix below — but don't let one bad
            # chunk zero out everything the OTHER chunks of this same
            # document already extracted successfully.
            _log_extraction_failure(doc, chunk_index=i, total_chunks=len(chunks))
            continue
        all_records.extend(_records_from_parsed_items(parsed, doc, population, intervention))
    return all_records
```
The bulk of the existing per-item record-building logic (currently inline in `_extract_one`, lines ~549-631 in the version I reviewed) should move into a `_records_from_parsed_items(parsed, doc, population, intervention)` helper so it can be called once per chunk without duplicating that logic — a straightforward extract-method refactor, no behavior change to that part.

**Why this closes the gap that a cap raise can't:**
- Cost and latency per document now scale with the document's actual length, not with a fixed guess at "how much could this document possibly need" — so there's no cap size that becomes wrong as documents grow, because each chunk's expected output stays roughly constant regardless of total document size.
- A parse failure or truncation on one chunk only loses that chunk's content, not the whole document's. Today, one bad response wipes out everything a 50-page guideline PDF might have offered.
- `extract_from_documents()` (the caller, ~line 512-533) doesn't need to change at all — it already just collects whatever `_extract_one()` returns per document via the existing `ThreadPoolExecutor`, so chunking is fully contained inside `_extract_one()`.

**Duplicate comparators across overlapping chunks are already handled — by the fix from last round.** The same comparator may legitimately appear in two adjacent chunks (that's what the overlap is for — better a duplicate than a lost row split at the boundary). You don't need new merge logic for this: `resolve_identities()`'s pre-clustering pass (`precluster_candidates()`, from the SoC-bundling/dedup fix) already collapses near-duplicate `as_stated` strings before A11 sees them, so a comparator extracted twice from overlapping chunk text resolves to one identity downstream, exactly the way two differently-worded mentions of the same drug already do.

**Add the visibility that's been missing this whole investigation:** right now, an empty or unparseable extraction response fails completely silently — that's why this took manual cross-tabulation across 403 calls to even find. Add a real log entry:
```python
def _log_extraction_failure(doc: RetrievedDocument, chunk_index: int, total_chunks: int) -> None:
    logger.warning(
        "a08.extraction: chunk %d/%d of %s returned no usable records "
        "(empty or unparseable response)", chunk_index + 1, total_chunks,
        doc.resolved_url or doc.url)
    # If your run already writes an "Errors and Retries"-style structured log,
    # append a row there too — this is exactly the kind of failure a
    # completeness/audit sheet should be able to show a reviewer directly,
    # instead of requiring someone to cross-reference 400 raw LLM calls by hand.
```

**Test without a full run** (this is the important one — it directly answers "did this fix actually recover the comparators we were missing"):
```python
import json
from jca_phase1.agents.a06_a08_retrieval import _extract_one
from jca_phase1.providers.search import RetrievedDocument  # adjust import to actual location

# Reuse the ACTUAL text of the document that was truncated in the last run —
# you have it: the SIOPE LGG guideline PDF that hit the 16000-token cap twice.
# Either re-fetch it live, or use a cached copy from the last run if one exists.
doc = RetrievedDocument(
    url="https://siope.eu/media/documents/escp-low-grade-gliomas-lgg.pdf",
    text=open("cached_siope_lgg_guideline.txt").read(),  # however you have it cached
    source_class="clinical_guideline", ok=True)

records = _extract_one(doc, population=<Tovorafenib LGG population fixture>,
                       intervention=<Tovorafenib fixture>, llm=llm)

names = {r.comparator.as_stated.lower() for r in records if r.comparator}
print(f"extracted {len(records)} records, comparator names: {names}")
for expected in ["tpcv", "carboplatin", "vincristine", "vinblastine"]:
    assert any(expected in n for n in names), f"Still missing: {expected}"
print("PASS: TPCV/CV/Vinblastine now recovered from the previously-truncated document")
```
This is the single test that actually answers your question — run it once with the fix in place, and you'll know directly whether this specific document (which alone covers 3 of your 6 missing GT comparators) now extracts completely, without waiting on a full ~24-minute production run to find out.

---

## Fix C — same chunking idea applied to `a06.query_vocabulary`

**File: `agents/a06_a08_retrieval.py`**, `build_vocabulary()` (~line 58-90). This prompt is a different shape of the same problem: it asks for one JSON object covering translated terminology across `STATE_LANGUAGE`'s ~23 distinct languages in a single call (line 70: `languages = sorted({lang for lang in STATE_LANGUAGE.values()})`), which is exactly why it's 100% truncating regardless of cap.

**Fix:** split `languages` into groups (e.g. 6-8 languages per call) and merge the resulting vocabularies:
```python
_LANGUAGE_BATCH_SIZE = 6

def build_vocabulary(population: Population, areas: Sequence[str],
                     llm: Optional[LLMClient] = None) -> QueryVocabulary:
    indication = population.value("indication_disease")
    vocab = QueryVocabulary(indication_synonyms=[indication] if indication else [])
    if llm is None or not indication:
        return vocab

    all_languages = sorted({lang for lang in STATE_LANGUAGE.values()})
    merged_localised: Dict[str, List[str]] = {}
    base_fields_done = False

    for start in range(0, len(all_languages), _LANGUAGE_BATCH_SIZE):
        lang_batch = all_languages[start:start + _LANGUAGE_BATCH_SIZE]
        payload = (f"INDICATION: {indication}\n"
                   f"DISEASE SUBTYPE: {population.value('disease_subtype_histology') or '(not provided)'}\n"
                   f"THERAPEUTIC AREA(S): {', '.join(areas) or '(unresolved)'}\n"
                   f"LANGUAGES: {', '.join(lang_batch)}\n")
        parsed = llm.call_json("a06.query_vocabulary", payload,
                               max_tokens=C.LLM.vocabulary_max_tokens, default={}) or {}
        if not isinstance(parsed, dict):
            parsed = {}
        if not base_fields_done:
            # Only need the non-language-specific fields once, from the first batch
            vocab.indication_synonyms = _dedup([indication] + (parsed.get("indication_synonyms") or []))
            vocab.indication_abbreviations = _dedup(parsed.get("indication_abbreviations") or [])
            vocab.disease_class_terms = _dedup(parsed.get("disease_class_terms") or [])
            vocab.outcome_requirement_terms = _dedup(parsed.get("outcome_requirement_terms") or [])
            base_fields_done = True
        localised = parsed.get("localised_assessment_terms") or {}
        for k, v in localised.items():
            if isinstance(v, list):
                merged_localised.setdefault(k, [])
                merged_localised[k] = _dedup(merged_localised[k] + v)

    vocab.localised_assessment_terms = merged_localised
    # ... rest of the existing safety-net / drug-name-stripping logic unchanged ...
    return vocab
```
This costs a few extra small LLM calls per run instead of one large one, which is a good trade — it's the same total work, just shaped so no single response has to hold all 23 languages' worth of translated terms at once.

**Test:**
```python
vocab = build_vocabulary(population=<fixture>, areas=["Oncology"], llm=llm)
missing = [lang for lang in STATE_LANGUAGE.values() if lang not in vocab.localised_assessment_terms]
assert not missing, f"Still missing languages after batching: {missing}"
print(f"PASS: all {len(vocab.localised_assessment_terms)} languages populated, none truncated")
```

---

## What "done" looks like

After Fix A is deployed, re-run the isolated test in Fix B against the cached SIOPE document — if it still truncates even at the raised cap, that confirms chunking (not a bigger number) was always the real requirement, and you should proceed straight to Fix B rather than iterating on the cap further. After Fix B and C are in, the next full pipeline run should show: `a06.query_vocabulary` and `a08.extraction` both showing zero calls at their configured cap in the `Bedrock Calls`/equivalent log, and the SIOPE LGG guideline document specifically producing multiple comparator records instead of zero — which should surface TPCV, Carboplatin+Vincristine, and Vinblastine as real candidates for the first time.
