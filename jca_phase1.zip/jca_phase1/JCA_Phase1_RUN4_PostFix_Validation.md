# JCA Phase 1 — Run 4 Post-Fix Validation (Tovorafenib)

**Run analyzed:** `RUN-20260923T184232-dbbdf4` (`JCA_Phase1_RUN-20260923T184232-dbbdf4.json`) — run after your team applied fixes from the prior gap analysis.
**Format note:** this run was exported as JSON, not xlsx, and this JSON includes the full `bedrock_calls` array with `user_prompt`/`response_text` for every one of 472 LLM calls — this let me verify some things directly this time (e.g., whether a specific document's extraction was truncated) instead of inferring them, which is a genuine improvement in auditability.

Evidence labels: `[JSON]` = read directly from this run's export. `[GT]` = from `jca gt.xlsx`. `[EXECUTED]` = verified by parsing/searching the actual data programmatically, not by eyeballing a sample.

**Headline: real quality improvement on what the pipeline does produce, but comparator recall against GT has not improved — it's still 1 of 7 real GT comparators, and two new low-quality entries appeared.** `num_comparators` went from 2 to 3, but that's not the right number to track — read on.

---

## 1. What's confirmed fixed

### 1a. Tovorafenib-as-its-own-comparator — gone
`[JSON]` — the final `comparators` list has 3 entries: `Dabrafenib+trametinib`, `chemotherapy`, `surgery and chemotherapy`. Tovorafenib does not appear as its own comparator anywhere. **Fixed, confirmed in production, not just in isolated testing.**

### 1b. Diacritic/accent bug — fixed, and it's visibly helping
`[JSON]` — the Dabrafenib+Trametinib comparator's evidence now includes French HAS-sourced quotes using the accented spelling ("Tovorafénib"/"tramétinib") that validated `SUPPORTED`, e.g. a quote from `has-sante.fr/jcms/p_4214262` grounding the comparator with `validation_verdict: SUPPORTED`. In the prior run, this class of evidence was being wrongly rejected as "about a different drug." **Fixed.**

### 1c. `a11.comparator_identity` schema mismatch — fixed, and working well
`[JSON]` — `bedrock_calls`, the single `a11.comparator_identity` call's `response_text` now returns exactly the nested per-component structure recommended:
```json
{"name": "Dabrafenib", "inn": "Dabrafenib", "atc_code": "L01EC02", "class_mechanism": "BRAF kinase inhibitor"},
{"name": "Trametinib", "inn": "Trametinib", "atc_code": "L01EE01", "class_mechanism": "MEK inhibitor"}
```
And it flows through to the final export: the `Dabrafenib+trametinib` comparator now shows `class_source: "source_stated"` with a populated `class_or_mechanism` (in the prior run this was `unresolved` on every combination, every run). **Fixed.**

### 1d. `a12.scope_adjudication` truncation — fixed
`[JSON]` — all 8 `a12.scope_adjudication` calls this run complete with well-formed, non-truncated JSON (max output 3377 tokens, none anywhere near a cap boundary). No more "adjudicator response could not be parsed" outcomes. **Fixed.**

### 1e. `a14.outcome_harmonization` truncation — fixed
`[JSON]` — both calls (4867 and 710 output tokens) end in clean, complete JSON. This was 100% truncated across all 3 prior runs; now resolved. **Fixed.**

### 1f. `a16.indication_synthesis` truncation — fixed
`[JSON]` — the single call (813 tokens) completes cleanly. **Fixed.**

### 1g. Leakage guard — fixed
`[JSON]` — `run_manifest.leakage_guard`: `allow_jca_reports: false`, `blocked_domains: ["health.ec.europa.eu"]`. I searched the full run export for the JCA report's known filename patterns (`hta_jca_mp`, `tovorafenib_summary-report`, `tovorafenib_report_en`): **zero occurrences anywhere in this run.** The answer-key report was not retrieved at all this time. **Fixed.**

That's six confirmed, verified fixes. Genuinely good progress — I want to say that plainly before getting into what's still wrong.

---

## 2. What's still broken

### 2a. `a06.query_vocabulary` — still truncating at 100%, cap raise wasn't enough
`[JSON]` — both `a06.query_vocabulary` calls this run hit exactly **4000** output tokens (the new, raised cap), and both response texts cut off mid-structure:
> `...` "requirements for endpoint selection in`
> `...` "sl": ["ocena zdravstvenih tehnologij", "poročilo o oceni", "klinična smernica", "priporočilo za zdravlj`

The cap was raised from 1500 → 4000, which is progress, but this prompt generates a full multilingual vocabulary (translated search-term sets across ~27 EU member-state languages plus English), and that output is naturally larger than 4000 tokens. **Still 2/2 = 100% truncated, same rate as 3 runs ago.** This needs either a much larger cap (I'd estimate 8000-10000 based on how much of the structure was still unwritten at the 4000-token cutoff) or restructuring the prompt to generate the vocabulary in per-language batches rather than one giant multilingual JSON object.

### 2b. `a08.extraction` — still truncating, and it's hitting exactly the documents that matter most
This is the important one, and I want to be precise about it because it directly explains why comparator recall hasn't improved.

`[JSON]` — I cross-referenced every `a08.extraction` call whose *input* document mentions vinblastine, carboplatin, vincristine, TPCV, everolimus, or bevacizumab (54 such calls) against whether that call actually produced extraction records. The overwhelming majority correctly produced 0 records because the drug is only mentioned in passing (e.g., an EU orphan-medicines list that happens to include everolimus for an unrelated indication) — that's correct behavior, not a bug. But three calls stand out:

| Source document | GT relevance | Result |
|---|---|---|
| `siope.eu/media/documents/escp-low-grade-gliomas-lgg.pdf` — GT's own cited source for TPCV, Carboplatin+Vincristine, and Vinblastine | Directly relevant to 3 of the 7 GT comparators | Retrieved **twice** this run; **both times hit the 16000-token cap and produced either 0 records or an unparseable response** |
| A Polish HTA "technology list" document (`bip.aotm.gov.pl/.../wykaz_tli/.../TL...`) whose URL pattern (`TL` = *terapia lekowa* / technology list) and content match on TPCV | Likely TPCV-relevant | Hit the 16000-token cap, response unparseable |
| The French HAS committee transcript for Ojemda (`has-sante.fr/jcms/p_4214264/.../ojemda-24062026-transcription-ct-ap583`), which discusses vinblastine, carboplatin, vincristine, and bevacizumab in the same passage | Likely comparator-committee-discussion content, exactly the kind of source that would state comparator recommendations explicitly | Hit the 16000-token cap, response unparseable |

`[EXECUTED]` — I confirmed by direct string search that **not a single structured comparator record** naming vinblastine, TPCV, everolimus, or bevacizumab was successfully extracted anywhere in this run (the only extracted records mentioning any of these terms are 2 records about carboplatin+vincristine, both correctly attributed to `subject_drug: "Dabrafenib plus trametinib"` from the ASCO source — i.e., genuinely about the D+T trial, not a tovorafenib-relative comparator claim, and correctly excluded downstream for that reason).

**This is the real reason TPCV, Vinblastine, Everolimus, and Bevacizumab+chemo still never reach adjudication: their primary, richest evidence sources are exactly the documents whose extraction response is too large for the 16000-token cap, so extraction returns nothing usable from them.** Your prior fix correctly got the `clinical_guideline` source class routed into extraction (it was previously skipping this class entirely at a 0/59 rate) — that routing fix worked. But the documents that class contains turn out to be dense enough that the *next* bottleneck, the extraction token cap, is now what's silently discarding them.

Practical implication: raising `extraction_max_tokens` further (currently `config.py`'s `extraction_max_tokens = 16000`) is worth trying, but a comprehensive guideline document covering many comparators for many populations may genuinely need more structured output than any single-shot JSON response comfortably handles. The more robust fix is likely chunking: split a large source document into sections before extraction (e.g., by heading, or a fixed character window with overlap) and extract each chunk separately, merging results — rather than asking one call to read up to 120,000 characters of source text and emit an unbounded number of JSON records in one uninterrupted response.

### 2c. New: A11's "excluded" verdict is not honored downstream
`[JSON]` — the `a11.comparator_identity` response explicitly excludes candidate index 7 with the reason: *"Combines a non-pharmacological intervention (surgery) with a generic chemotherapy category; not resolvable as a single substance-based comparator identity."* That candidate is "surgery and chemotherapy." Yet **it still appears in the final `comparators` output** — `class_source: "unresolved"`, `scope_adjudication.verdict: "uncertain"`. A11 correctly determined this candidate should be dropped, and downstream consolidation (A12/A14) proceeded to adjudicate and publish it anyway. This is a new defect, not present in the runs I reviewed before the a11 schema fix (because before the fix, a11's output wasn't being consumed as authoritatively). **File to check: wherever the consolidation stage (`A14`) reads a11's `excluded` list — it needs to actually drop those candidates before they reach A12, not just before they get an identity.**

### 2d. New: vague, non-specific mentions are being treated as first-class comparators
Two of this run's 3 final comparators are not real, nameable treatments:
- **"chemotherapy"** — sourced from an EMA EPAR sentence: *"It must submit final results from an ongoing clinical study in patients with paediatric low-grade glioma from six months of age comparing the effectiveness and safety of Ojemda with chemotherapy."* `[JSON]` This is a description of a **future, ongoing confirmatory trial commitment** (a regulatory obligation), not a statement that chemotherapy is an established comparator today. A12 adjudicated it `in_scope` anyway, reasoning "directly establishing chemotherapy as a comparator." That's a stretch — the source describes a planned study, not a positioning statement.
- **"surgery and chemotherapy"** — sourced from: *"At the time of the approval of Ojemda, there were limited treatment options for patients with paediatric low-grade glioma, including surgery and chemotherapy."* This is generic background scene-setting, not a comparator recommendation, and — as noted in 2c — A11 itself said so before being overridden downstream.

Neither of these corresponds to any of the 7 named GT comparators, and both dilute the "3 comparators" headline number with entries that a clinician reviewing the output would immediately recognize as not real, specific comparators. This is worth a design decision: should A08 extraction be tagging category-level or forward-looking-trial mentions as `comparator.role: active_comparator` at all, or should there be a distinct handling for "not yet an established comparator" / "too generic to be a named treatment" that keeps them out of the final comparator list (perhaps surfaced separately as context, the way `A16 Dropped Comparators` worked in the xlsx export)?

### 2e. New, lower-priority: the same comparator got two different A12 verdicts
`[JSON]` — Dabrafenib+Trametinib was adjudicated twice: one call returned `in_scope` (3377 tokens, French-sourced evidence), the other returned `uncertain` (2735 tokens, evidence framing it as "prior/ineligible therapy before tovorafenib initiation, supporting a sequential rather than comparator relationship"). The final export shows only the `in_scope` verdict. This likely reflects the A11 grouping merging multiple named variants (the A11 response shows 4 separate combination-name variants — "Dabrafenib + Trametinib," "Dabrafenib (Finlee) + Trametinib," "Trametinib (Spexotras) + Dabrafenib," "Trametinib + Dabrafenib" — that get treated as one comparator downstream) into a single final entry, each variant adjudicated separately, with the more favorable verdict winning. That may be reasonable behavior, but it's not visible or explained anywhere in the export — worth adding a note or a `verdicts_considered` field so a reviewer can see that a comparator's final verdict was chosen from multiple adjudications rather than being the only one computed, especially since the discarded `uncertain` verdict raises a real, unresolved question (is D+T a true comparator, or is it prior therapy the patient must have already failed?) that GT itself actually splits by population (PICO 5 treats it as a comparator for the BRAF V600E subgroup specifically).

---

## 3. GT comparator ledger — updated

| GT comparator `[GT]` | Run 3 status | Run 4 status | What changed |
|---|---|---|---|
| Dabrafenib + Trametinib | Found, but `uncertain` verdict, unresolved identity, French evidence wrongly excluded | **Found, `in_scope`, identity fully resolved (both component INNs/ATC codes), French evidence correctly included** | Genuinely fixed — this is now a clean, GT-aligned comparator |
| Carboplatin + Vincristine (CV) | Retrieved, adjudicated, excluded on line-of-therapy technicality | Evidence about CV now reaches extraction (confirming the retrieval fix worked) but is only found in the context of the D+T trial (correctly excluded there); its primary GT-cited guideline source (SIOPE LGG PDF) hit the extraction token cap | **Still missing** — root cause moved from "excluded on a technicality" to "primary source never successfully extracted" |
| Vinblastine | Same as CV | Same underlying cause — mentioned in the truncated SIOPE LGG document, never became a structured extraction record | **Still missing** |
| TPCV | Never entered the pipeline at all | A likely-relevant Polish HTA document was retrieved and reached extraction, but its response hit the token cap and failed to parse; the SIOPE LGG guideline (also relevant) was likewise truncated | **Still missing**, but now at least reaches extraction — closer than before |
| Everolimus | Never entered the pipeline at all | Mentioned only in generic EU orphan-medicines marketing-authorisation lists (not pLGG-specific) and in the truncated SIOPE LGG document | **Still missing** |
| Bevacizumab + chemotherapy | Never entered the pipeline at all | Mentioned in Dutch/NCCN general glioma guidance and the truncated SIOPE/HAS documents, none producing a structured record | **Still missing** |
| Trametinib (monotherapy) | Never entered the pipeline at all | Still never appears as a standalone entity — always bundled with dabrafenib | **Still missing** — unaddressed, no fix targeted this in the last round |
| *(non-GT)* "chemotherapy" | — | New — a generic, non-specific entry from a forward-looking trial-commitment sentence | **New defect (§2d)** |
| *(non-GT)* "surgery and chemotherapy" | — | New — should have been excluded per A11's own reasoning but wasn't (§2c) | **New defect (§2c)** |

Net position: **1 of 7 GT comparators correctly captured** (same count as before, but now genuinely correct rather than degraded), **0 incorrect drug-identity comparators** (the Tovorafenib-self bug is gone), and **2 new low-quality generic entries** that a reviewer would need to manually filter out.

---

## 4. What to fix next, in priority order

1. **Raise or restructure `a08.extraction`'s handling of large source documents.** This is the single highest-leverage fix remaining — it's the confirmed, direct cause of TPCV/CV/Vinblastine/Everolimus/Bevacizumab still being absent. Either raise `extraction_max_tokens` further (try 24000-32000 and see if the SIOPE LGG document completes) or, more robustly, chunk large documents before extraction rather than relying on ever-larger single-shot caps. Add logging for the empty-list/parse-failure path in `_extract_one()` so this stops requiring manual cross-tabulation to discover.
2. **Raise `a06.query_vocabulary`'s cap further** (4000 clearly wasn't enough) or restructure it to generate per-language batches.
3. **Fix A11 exclusion not being honored** — whatever consolidation step reads a11's response needs to actually drop items in the `excluded` array before they reach A12, not just before they get an identity.
4. **Add a filter (or at least a distinct flag) for generic/category and forward-looking-trial mentions** so "chemotherapy" (sourced from a future confirmatory-study commitment) and "surgery and chemotherapy" (sourced from generic background text) don't get adjudicated as first-class comparators alongside genuinely named, source-recommended treatments.
5. **Make multi-verdict comparator grouping visible.** If a comparator's final verdict is chosen from more than one A12 adjudication (as happened for Dabrafenib+Trametinib), surface that in the export so a reviewer can see the discarded verdict and its reasoning, rather than silently keeping only the favorable one.

Once #1 is done, re-run and check specifically whether the SIOPE LGG guideline document's extraction completes without hitting the cap — that single document, if fully extracted, is likely to surface 3 of your remaining 6 missing GT comparators (TPCV, CV, Vinblastine) in one pass, since GT cites it as their common source.
